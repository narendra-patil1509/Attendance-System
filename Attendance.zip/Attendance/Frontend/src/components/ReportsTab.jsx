import { useState, useEffect } from 'react';
import axios from 'axios';
import { Download, FileText, CheckCircle, XCircle, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

const API_URL = `http://${window.location.hostname}:5000/api`;

export default function ReportsTab() {
  const [logs, setLogs] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const adminToken = sessionStorage.getItem('adminToken');

  const fetchLogs = async () => {
    try {
      const { data } = await axios.get(`${API_URL}/attendance/today`, {
        headers: { Authorization: `Bearer ${adminToken}` }
      });
      setLogs(data);
    } catch (err) {
      setError('Failed to load logs');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const handleExport = async () => {
    try {
      const response = await axios.get(`${API_URL}/attendance/export`, {
        headers: { Authorization: `Bearer ${adminToken}` },
        responseType: 'blob'
      });
      
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'attendance_today.xlsx');
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (err) {
      setError('Failed to export report');
    }
  };

  if (loading) return <div className="p-8 text-center text-muted-foreground font-medium">Loading report...</div>;

  const filteredLogs = logs.filter(log => 
    log.employee_name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    log.emp_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
    log.status.toLowerCase().includes(searchQuery.toLowerCase()) ||
    log.admin_name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-8 flex flex-col h-full bg-background text-foreground animate-in fade-in">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h2 className="text-2xl font-bold text-foreground mb-1 flex items-center gap-2">
            <FileText className="w-6 h-6 text-primary" /> Attendance Report
          </h2>
          <p className="text-muted-foreground font-medium">View, search, and export all attendance logs for today.</p>
        </div>
        
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search reports..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 h-10 bg-card border-border w-full focus-visible:ring-primary"
            />
          </div>
          <Button
            onClick={handleExport}
            className="gap-2 bg-secondary hover:bg-secondary/90 text-secondary-foreground px-5 h-10 font-bold shadow-lg shadow-secondary/20 transition hover:-translate-y-0.5 shrink-0"
          >
            <Download className="w-5 h-5" /> Export
          </Button>
        </div>
      </div>

      {error && <div className="p-4 bg-destructive/10 text-destructive font-medium rounded-xl mb-4 border border-destructive/20">{error}</div>}

      <div className="flex-1 min-h-0 bg-card border border-border rounded-2xl shadow-sm flex flex-col overflow-hidden">
        <div className="overflow-y-auto flex-1 style-scrollbar">
          <Table className="relative">
            <TableHeader className="bg-muted/30 sticky top-0 z-10 backdrop-blur-md shadow-sm">
              <TableRow className="border-border hover:bg-muted/30">
                <TableHead className="font-bold text-muted-foreground uppercase tracking-widest text-xs h-12">Time</TableHead>
                <TableHead className="font-bold text-muted-foreground uppercase tracking-widest text-xs h-12">Employee</TableHead>
                <TableHead className="font-bold text-muted-foreground uppercase tracking-widest text-xs h-12">Admin Approver</TableHead>
                <TableHead className="font-bold text-muted-foreground uppercase tracking-widest text-xs h-12">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody className="divide-y divide-border">
              {filteredLogs.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="h-48 text-center text-muted-foreground font-medium text-lg">
                    {searchQuery ? 'No matching records found.' : 'No attendance records for today.'}
                  </TableCell>
                </TableRow>
              ) : (
                filteredLogs.map((log) => (
                  <TableRow key={log.id} className="hover:bg-muted border-border transition">
                  <TableCell className="font-semibold tracking-wide text-muted-foreground align-middle">
                    {new Date(log.entry_timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </TableCell>
                  <TableCell className="align-middle py-3">
                    <div className="font-bold text-foreground text-base">{log.employee_name}</div>
                    <div className="text-xs text-primary font-bold font-mono tracking-wider mt-0.5">{log.emp_id}</div>
                  </TableCell>
                  <TableCell className="font-medium text-muted-foreground align-middle">
                     <div className="flex items-center gap-2">
                       <span className="w-6 h-6 rounded-full bg-muted flex items-center justify-center text-xs font-bold text-foreground">{log.admin_name.charAt(0)}</span>
                       {log.admin_name}
                     </div>
                  </TableCell>
                  <TableCell className="align-middle">
                    {log.status === 'Approved' ? (
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-green-50 text-green-600 gap-1.5 border border-green-200 shadow-sm">
                        <CheckCircle className="w-3.5 h-3.5" /> {log.status}
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-red-50 text-red-600 gap-1.5 border border-red-200 shadow-sm">
                        <XCircle className="w-3.5 h-3.5" /> {log.status}
                      </span>
                    )}
                  </TableCell>
                </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
