import { useState, useEffect } from 'react';
import axios from 'axios';
import { jwtDecode } from 'jwt-decode';
import { CheckCircle, XCircle, User, Fingerprint, Phone, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardTitle } from '@/components/ui/card';

const API_URL = `http://${window.location.hostname}:5000/api`;

export default function VerificationModal({ token, onClose }) {
  const [employee, setEmployee] = useState(null);
  const [decodeError, setDecodeError] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const adminToken = sessionStorage.getItem('adminToken');

  useEffect(() => {
    try {
      const decoded = jwtDecode(token);
      setEmployee(decoded);
    } catch (err) {
      setDecodeError(true);
    }
  }, [token]);

  const handleAction = async (status) => {
    setLoading(true);
    try {
      await axios.post(
        `${API_URL}/attendance/verify`,
        { token, status },
        { headers: { Authorization: `Bearer ${adminToken}` } }
      );
      
      onClose(`Attendance ${status}`, null);
    } catch (err) {
      const msg = err.response?.data?.message || 'Verification failed';
      onClose(null, msg);
    } finally {
      setLoading(false);
    }
  };

  if (decodeError) {
    return (
      <div className="fixed inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in zoom-in duration-200">
        <Card className="rounded-3xl p-8 max-w-sm w-full text-center shadow-2xl border-border bg-card">
          <div className="w-20 h-20 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-6 ring-4 ring-destructive/20">
             <AlertTriangle className="w-10 h-10 text-destructive" />
          </div>
          <CardTitle className="text-2xl font-bold text-foreground mb-3 tracking-tight">Invalid QR Code</CardTitle>
          <p className="text-muted-foreground font-medium mb-8">The scanned code is not recognized by the system.</p>
          <Button
            variant="secondary"
            onClick={() => onClose(null, 'Invalid QR Code')}
            className="w-full text-secondary-foreground font-bold h-12 text-base transition-all"
          >
            Close Window
          </Button>
        </Card>
      </div>
    );
  }

  if (!employee) return null;

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-in fade-in duration-300">
      <Card className="rounded-3xl max-w-md w-full shadow-2xl overflow-hidden scale-in border-border bg-card">
        <div className="bg-primary/10 p-8 text-center border-b border-border">
            <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-md ring-4 ring-primary/30">
                <User className="w-10 h-10 text-primary" />
            </div>
            <CardTitle className="text-2xl font-extrabold text-foreground tracking-tight mb-1">Verify Identity</CardTitle>
            <p className="text-primary font-semibold text-sm uppercase tracking-widest">Attendance Request</p>
        </div>

        <CardContent className="p-8">
            <div className="space-y-4 mb-8">
                <div className="flex flex-col bg-muted/30 p-4 rounded-xl border border-border">
                    <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1 flex items-center gap-2"><User className="w-3.5 h-3.5"/> Full Name</span>
                    <span className="text-lg font-bold text-foreground">{employee.full_name}</span>
                </div>
                <div className="flex flex-col bg-muted/30 p-4 rounded-xl border border-border">
                    <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1 flex items-center gap-2"><Fingerprint className="w-3.5 h-3.5"/> Employee ID</span>
                    <span className="font-mono text-xl font-bold text-primary tracking-wider">{employee.emp_id}</span>
                </div>
                <div className="flex flex-col bg-muted/30 p-4 rounded-xl border border-border">
                    <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1 flex items-center gap-2"><Phone className="w-3.5 h-3.5"/> Mobile Number</span>
                    <span className="font-mono text-lg font-bold text-foreground">{employee.mobile_number || 'N/A'}</span>
                </div>
            </div>

            <div className="flex gap-4">
                <Button
                    onClick={() => handleAction('Rejected')}
                    disabled={loading}
                    className="flex-1 h-14 text-base gap-2 font-bold transition-all shadow-lg shadow-red-600/20 bg-red-600 text-white hover:bg-red-700 focus:ring-red-600"
                >
                    <XCircle className="w-5 h-5" />
                    Reject
                </Button>
                <Button
                    onClick={() => handleAction('Approved')}
                    disabled={loading}
                    className="flex-1 h-14 text-base gap-2 font-bold transition-all shadow-lg shadow-green-600/20 bg-green-600 text-white hover:bg-green-700 focus:ring-green-600"
                >
                    <CheckCircle className="w-5 h-5" />
                    Approve
                </Button>
            </div>
        </CardContent>
      </Card>
    </div>
  );
}
