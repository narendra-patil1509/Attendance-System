import { useState } from 'react';
import axios from 'axios';
import { Search, UserCheck, XCircle, AlertCircle, CheckCircle2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const API_URL = `http://${window.location.hostname}:5000/api`;

export default function ManualEntryTab() {
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const adminToken = sessionStorage.getItem('adminToken');

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    setMessage('');
    setError('');
    
    try {
      const { data } = await axios.get(`${API_URL}/attendance/search?q=${searchQuery}`, {
        headers: { Authorization: `Bearer ${adminToken}` }
      });
      setResults(data);
      if (data.length === 0) setError('No employees found');
    } catch (err) {
      setError('Search failed');
    } finally {
      setLoading(false);
    }
  };

  const handleManualEntry = async (empId, status) => {
    setMessage('');
    setError('');
    try {
      const { data } = await axios.post(
        `${API_URL}/attendance/manual`,
        { emp_id: empId, status },
        { headers: { Authorization: `Bearer ${adminToken}` } }
      );
      setMessage(data.message);
      setTimeout(() => setMessage(''), 3000);
    } catch (err) {
      setError(err.response?.data?.message || 'Manual entry failed');
      setTimeout(() => setError(''), 3000);
    }
  };

  return (
    <div className="p-8 bg-background text-foreground h-full flex flex-col">
      <div className="max-w-2xl mx-auto w-full">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground mb-2">Manual Entry</h2>
          <p className="text-muted-foreground">Search for an employee to manually record their attendance.</p>
        </div>

        <form onSubmit={handleSearch} className="flex gap-4 mb-8">
          <div className="relative flex-1 shadow-sm">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by Employee ID or Name..."
              className="w-full pl-12 h-12 bg-card border-border text-base focus-visible:ring-primary"
            />
          </div>
          <Button 
            type="submit" 
            disabled={loading}
            className="h-12 px-8 font-bold text-base bg-primary hover:bg-primary/90 text-primary-foreground shadow-md transition-all"
          >
            {loading ? 'Searching...' : 'Search'}
          </Button>
        </form>

        {message && (
          <div className="mb-6 p-4 bg-secondary/10 text-secondary border border-secondary/20 rounded-xl flex items-center gap-3 animate-in fade-in">
            <CheckCircle2 className="w-5 h-5 shrink-0" />
            <span className="font-medium">{message}</span>
          </div>
        )}

        {error && (
          <div className="mb-6 p-4 bg-destructive/10 text-destructive border border-destructive/20 rounded-xl flex items-center gap-3 animate-in fade-in">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <span className="font-medium">{error}</span>
          </div>
        )}

        {results.length > 0 && (
          <div className="bg-card rounded-2xl border border-border overflow-hidden shadow-sm animate-in slide-in-from-bottom-2">
            <ul className="divide-y divide-border">
              {results.map((emp) => (
                <li key={emp.emp_id} className="p-4 hover:bg-muted/50 transition flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-foreground text-lg">{emp.full_name}</h4>
                    <p className="text-sm font-medium text-muted-foreground mt-0.5"><span className="font-mono text-primary">{emp.emp_id}</span> • {emp.mobile_number || 'No phone'}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => handleManualEntry(emp.emp_id, 'Rejected')}
                      className="gap-2 font-bold bg-red-600 text-white hover:bg-red-700"
                    >
                      <XCircle className="w-4 h-4" /> Reject
                    </Button>
                    <Button
                      onClick={() => handleManualEntry(emp.emp_id, 'Approved')}
                      className="gap-2 font-bold bg-green-600 text-white hover:bg-green-700"
                    >
                      <UserCheck className="w-4 h-4" /> Approve
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}
