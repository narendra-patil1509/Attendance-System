import { useEffect, useState } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';
import { AlertCircle, QrCode } from 'lucide-react';
import VerificationModal from './VerificationModal';

export default function ScannerTab() {
  const [scannedData, setScannedData] = useState(null);
  const [error, setError] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    let scanner;
    if (!isModalOpen) {
      scanner = new Html5QrcodeScanner('reader', {
        qrbox: { width: 300, height: 300 },
        fps: 10,
        aspectRatio: 1.0
      });

      scanner.render(
        (data) => {
          scanner.clear();
          setScannedData(data); // data is the JWT token
          setIsModalOpen(true);
        },
        (err) => {
          // Ignore scanning noise
        }
      );
    }

    return () => {
      if (scanner) {
        scanner.clear().catch(e => console.error(e));
      }
    };
  }, [isModalOpen]);

  const handleVerificationComplete = (successMessage, errorMessage) => {
    setIsModalOpen(false);
    setScannedData(null);
    if (errorMessage) {
      setError(errorMessage);
      setTimeout(() => setError(''), 5000);
    }
  };

  return (
    <div className="p-8 w-full flex-1 flex flex-col items-center justify-center bg-background text-foreground">
      <div className="max-w-xl w-full">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/20 text-primary mb-4 ring-2 ring-primary/40">
             <QrCode className="w-8 h-8" />
          </div>
          <h2 className="text-3xl font-bold text-foreground mb-2">Scan Employee QR</h2>
          <p className="text-muted-foreground font-medium">Position the QR code within the frame to verify attendance.</p>
        </div>

        {error && (
            <div className="mb-6 p-4 bg-destructive/10 text-destructive rounded-xl flex items-start gap-3 border border-destructive/20 shadow-sm animate-in fade-in">
                <AlertCircle className="w-6 h-6 shrink-0 mt-0.5" />
                <span className="font-medium">{error}</span>
            </div>
        )}

        {!isModalOpen && (
          <div className="bg-card p-6 rounded-3xl border-2 border-dashed border-border shadow-inner">
            <div id="reader" className="w-full overflow-hidden rounded-xl bg-background border border-border"></div>
          </div>
        )}
      </div>

      {isModalOpen && scannedData && (
        <VerificationModal 
          token={scannedData} 
          onClose={handleVerificationComplete} 
        />
      )}
    </div>
  );
}
