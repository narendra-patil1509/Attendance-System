import { useState, useRef } from 'react';
import axios from 'axios';
import { Upload, FileSpreadsheet, XCircle, CheckCircle2, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const API_URL = `http://${window.location.hostname}:5000/api`;

export default function EmployeesTab() {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const fileInputRef = useRef(null);

  const adminToken = sessionStorage.getItem('adminToken');

  const handleFileChange = (e) => {
    setMessage('');
    setError('');
    const selectedFile = e.target.files[0];
    if (selectedFile && selectedFile.name.endsWith('.xlsx')) {
      setFile(selectedFile);
    } else {
      setFile(null);
      setError('Please select a valid Excel (.xlsx) file.');
    }
  };

  const clearFile = () => {
    setFile(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleUpload = async () => {
    if (!file) {
      setError('No file selected.');
      return;
    }

    setLoading(true);
    setMessage('');
    setError('');

    const formData = new FormData();
    formData.append('file', file);

    try {
      const { data } = await axios.post(`${API_URL}/employee/upload`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          Authorization: `Bearer ${adminToken}`
        }
      });
      setMessage(data.message);
      clearFile();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to upload Excel file.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8 bg-background text-foreground h-full flex flex-col">
      <div className="max-w-2xl mx-auto w-full">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground mb-2">Manage Employees</h2>
          <p className="text-muted-foreground">Bulk import or update employee data by uploading an Excel (.xlsx) file. Ensure the Excel has a header row and columns are: A: ID, B: Name, C: Mobile Number.</p>
        </div>

        {message && (
          <div className="mb-6 p-4 bg-secondary/10 text-secondary border border-secondary/20 rounded-xl flex items-center gap-3 animate-in fade-in">
            <CheckCircle2 className="w-5 h-5 shrink-0" />
            <span className="font-medium">{message}</span>
          </div>
        )}

        {error && (
          <div className="mb-6 p-4 bg-destructive/10 text-destructive border border-destructive/20 rounded-xl flex items-center gap-3 animate-in fade-in">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <span className="font-medium">{error}</span>
          </div>
        )}

        <div className="bg-card border-2 border-dashed border-border rounded-2xl p-8 flex flex-col items-center justify-center text-center">
            {!file ? (
              <>
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <FileSpreadsheet className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-lg font-bold text-foreground mb-2">Upload Excel File</h3>
                <p className="text-muted-foreground text-sm mb-6 max-w-sm">
                  Drag and drop your file here, or click the button below to browse your files.
                </p>
                <input
                  type="file"
                  accept=".xlsx"
                  className="hidden"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                />
                <Button onClick={() => fileInputRef.current?.click()} className="font-bold">
                  Browse Files
                </Button>
              </>
            ) : (
              <div className="w-full">
                <div className="flex items-center justify-between p-4 bg-muted/50 rounded-xl mb-6">
                  <div className="flex items-center gap-3 overflow-hidden">
                    <FileSpreadsheet className="w-6 h-6 text-primary shrink-0" />
                    <span className="font-medium truncate">{file.name}</span>
                  </div>
                  <Button variant="ghost" size="icon" onClick={clearFile} className="text-muted-foreground hover:text-destructive shrink-0">
                    <XCircle className="w-5 h-5" />
                  </Button>
                </div>
                <Button 
                  onClick={handleUpload} 
                  disabled={loading}
                  className="w-full h-12 font-bold text-base gap-2"
                >
                  <Upload className="w-5 h-5" />
                  {loading ? 'Uploading & Processing...' : 'Upload Data'}
                </Button>
              </div>
            )}
        </div>
      </div>
    </div>
  );
}
