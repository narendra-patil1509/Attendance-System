import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import { Lock, User, AlertCircle, Sliders, Check } from 'lucide-react';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export default function AdminLogin() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (sessionStorage.getItem('adminToken')) {
      navigate('/admin/dashboard');
    }
  }, [navigate]);

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const { data } = await axios.post(`http://${window.location.hostname}:5000/api/admin/login`, { username, password });
      sessionStorage.setItem('adminToken', data.token);
      sessionStorage.setItem('adminName', data.full_name);
      navigate('/admin/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center p-4 selection:bg-primary selection:text-primary-foreground">
      <Card className="max-w-md w-full shadow-2xl border-border bg-card">
        <CardHeader className="text-center bg-muted/30 border-b border-border space-y-2 pb-6">
          <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-4 border-[6px] border-background shadow-lg relative">
             <Sliders className="w-10 h-10 text-primary-foreground" />
             <div className="absolute -top-1 -right-1 w-7 h-7 bg-primary rounded-full border-[3px] border-background flex items-center justify-center text-primary-foreground">
               <Check className="w-4 h-4" strokeWidth={4} />
             </div>
          </div>
          <CardTitle className="text-3xl font-extrabold tracking-widest text-foreground">
            ON<span className="text-primary">ATTENDI</span>
          </CardTitle>
          <CardDescription className="text-primary font-bold tracking-[0.2em] text-xs uppercase mt-1">
            DIGITAL MARKETING
          </CardDescription>
        </CardHeader>

        <CardContent className="p-8">
          {error && (
            <div className="mb-6 p-4 bg-destructive/10 text-destructive rounded-lg flex items-start gap-3 text-sm border border-destructive/20 font-medium animate-in fade-in">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-2">
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground/50" />
                <Input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="h-12 w-full pl-10 bg-background border-border focus-visible:ring-primary text-base"
                  placeholder="Username"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground/50" />
                <Input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-12 w-full pl-10 bg-background border-border focus-visible:ring-primary text-base"
                  placeholder="Password"
                />
              </div>
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full h-12 mt-4 font-bold text-base bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/20 transition-all font-sans"
            >
              {loading ? 'Authenticating...' : 'Sign In'}
            </Button>
          </form>

          <div className="mt-6 text-center text-sm text-muted-foreground">
            Don't have an account?{' '}
            <Link to="/admin/signup" className="text-primary font-medium hover:underline">
              Create an account
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
