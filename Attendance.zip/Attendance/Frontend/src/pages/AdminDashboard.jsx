import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { io } from 'socket.io-client';
import axios from 'axios';
import { LayoutDashboard, Users, FileBarChart, LogOut, QrCode, Database, Sliders, Check } from 'lucide-react';
import ScannerTab from '../components/ScannerTab';
import ManualEntryTab from '../components/ManualEntryTab';
import ReportsTab from '../components/ReportsTab';
import EmployeesTab from '../components/EmployeesTab';

import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const API_URL = `http://${window.location.hostname}:5000/api`;
const SOCKET_URL = `http://${window.location.hostname}:5000`;

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('scanner');
  const [stats, setStats] = useState({
    totalExpected: 0,
    entered: 0,
    remaining: 0,
    adminApprovedLog: 0
  });

  const adminName = sessionStorage.getItem('adminName');
  const token = sessionStorage.getItem('adminToken');

  useEffect(() => {
    if (!token) {
      navigate('/admin/login');
      return;
    }

    const fetchStats = async () => {
      try {
        const { data } = await axios.get(`${API_URL}/attendance/stats`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setStats(data);
      } catch (error) {
        if (error.response?.status === 401) {
          sessionStorage.removeItem('adminToken');
          navigate('/admin/login');
        }
      }
    };

    fetchStats();

    const socket = io(SOCKET_URL);
    socket.emit('join-admin-room');

    socket.on('new-attendance-entry', () => {
      fetchStats();
    });

    return () => {
      socket.disconnect();
    };
  }, [token, navigate]);

  const handleLogout = () => {
    sessionStorage.removeItem('adminToken');
    sessionStorage.removeItem('adminName');
    navigate('/admin/login');
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col md:flex-row font-sans selection:bg-primary selection:text-primary-foreground">
      {/* Sidebar */}
      <div className="w-full md:w-72 bg-card border-r border-border flex flex-col shadow-2xl z-10">
        <div className="p-6 border-b border-border bg-muted/20">
          <div className="flex items-center gap-3 mb-1">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center border-2 border-background shadow-sm relative shrink-0">
               <Sliders className="w-5 h-5 text-primary-foreground" />
               <div className="absolute -top-1 -right-1 w-4 h-4 bg-primary rounded-full border border-background flex items-center justify-center text-primary-foreground">
                 <Check className="w-2 h-2" strokeWidth={4} />
               </div>
            </div>
            <h1 className="text-2xl font-extrabold tracking-widest text-foreground leading-none">
              ON<span className="text-primary">ATTENDI</span>
            </h1>
          </div>
          <p className="text-primary font-bold tracking-widest text-[10px] ml-[3.25rem] uppercase mb-4">Mark Attendies</p>
          <p className="text-muted-foreground text-sm font-medium">Welcome, <span className="text-foreground">{adminName}</span></p>
        </div>
        
        <nav className="flex-1 p-4 space-y-2 mt-4">
          <Button
            variant={activeTab === 'scanner' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('scanner')}
            className={`w-full justify-start gap-3 h-12 text-base ${activeTab === 'scanner' ? 'shadow-md shadow-primary/20 bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}
          >
            <QrCode className="w-5 h-5" />
            Live Scanner
          </Button>
          <Button
            variant={activeTab === 'manual' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('manual')}
            className={`w-full justify-start gap-3 h-12 text-base ${activeTab === 'manual' ? 'shadow-md shadow-primary/20 bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}
          >
            <Users className="w-5 h-5" />
            Manual Entry
          </Button>
          <Button
            variant={activeTab === 'employees' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('employees')}
            className={`w-full justify-start gap-3 h-12 text-base ${activeTab === 'employees' ? 'shadow-md shadow-primary/20 bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}
          >
            <Database className="w-5 h-5" />
            Manage Employees
          </Button>
          <Button
            variant={activeTab === 'reports' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('reports')}
            className={`w-full justify-start gap-3 h-12 text-base ${activeTab === 'reports' ? 'shadow-md shadow-primary/20 bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}
          >
            <FileBarChart className="w-5 h-5" />
            Report
          </Button>
        </nav>

        <div className="p-4 border-t border-border bg-muted/10">
          <Button 
            variant="ghost" 
            onClick={handleLogout} 
            className="w-full justify-start gap-3 h-12 text-destructive hover:text-destructive hover:bg-destructive/10 text-base"
          >
            <LogOut className="w-5 h-5" />
            Sign Out
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-6 md:p-8 overflow-y-auto bg-background/95 flex flex-col">
        {/* Real-time Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 shrink-0">
          <StatCard title="Total Expected" value={stats.totalExpected} color="bg-primary" />
          <StatCard title="Entered Today" value={stats.entered} color="bg-secondary" />
          <StatCard title="Remaining" value={stats.remaining} color="bg-accent" />
          <StatCard title="My Approvals" value={stats.adminApprovedLog} color="bg-green-500" />
        </div>

        {/* Tab Content */}
        <Card className="shadow-2xl border-border bg-card min-h-[500px] flex flex-col overflow-hidden">
          {activeTab === 'scanner' && <ScannerTab />}
          {activeTab === 'manual' && <ManualEntryTab />}
          {activeTab === 'reports' && <ReportsTab />}
          {activeTab === 'employees' && <EmployeesTab />}
        </Card>
      </div>
    </div>
  );
}

function StatCard({ title, value, color }) {
  const indicatorClass = color.split(' ').find(c => c.startsWith('bg-')) || 'bg-primary';
  
  return (
    <Card className="shadow-sm border-border bg-card transition-all hover:shadow-md hover:-translate-y-0.5">
      <CardContent className="p-4 flex items-center gap-4">
        <div className={`w-1.5 h-10 rounded-full ${indicatorClass} shadow-sm shrink-0`} />
        <div className="flex flex-col justify-center">
          <p className="text-muted-foreground text-[10px] font-bold tracking-widest uppercase mb-1">{title}</p>
          <p className="text-2xl font-black text-foreground leading-none tracking-tight">{value}</p>
        </div>
      </CardContent>
    </Card>
  );
}
