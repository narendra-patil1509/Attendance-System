import { useState, useEffect } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import axios from 'axios';
import { io } from 'socket.io-client';
import { AlertCircle, CheckCircle2, XCircle, QrCode } from 'lucide-react';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const API_URL = `http://${window.location.hostname}:5000/api`;
const SOCKET_URL = `http://${window.location.hostname}:5000`;

export default function EmployeePage() {
  const [empId, setEmpId] = useState('');
  const [fullName, setFullName] = useState('');
  const [qrData, setQrData] = useState(null);
  const [timeLeft, setTimeLeft] = useState(0);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [notification, setNotification] = useState(null);

  useEffect(() => {
    let timer;
    if (timeLeft > 0 && qrData) {
      timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && qrData) {
      setQrData(null);
    }
    return () => clearInterval(timer);
  }, [timeLeft, qrData]);

  useEffect(() => {
    let socket;
    if (qrData && empId) {
      socket = io(SOCKET_URL);
      socket.emit('join-employee-room', empId);
      
      socket.on('attendance-update', (data) => {
        setNotification(data.status);
        setQrData(null);
        setTimeLeft(0);
      });
    }
    return () => {
      if (socket) socket.disconnect();
    };
  }, [qrData, empId]);

  const generateQRCode = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await axios.post(`${API_URL}/employee/generate-qr`, {
        emp_id: empId,
        full_name: fullName
      });
      
      const token = response.data.token;
      setQrData(token);
      setTimeLeft(90);

    } catch (err) {
      setError(err.response?.data?.message || 'Failed to generate QR Code. Please check your details.');
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setEmpId('');
    setFullName('');
    setQrData(null);
    setTimeLeft(0);
    setError('');
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col items-center justify-center p-4 selection:bg-primary selection:text-primary-foreground">
      <Card className="max-w-md w-full shadow-2xl overflow-hidden border-border bg-card">
        <CardHeader className="text-center bg-muted/30 border-b border-border space-y-2 pb-6">
            <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-2 ring-2 ring-primary/40">
                <QrCode className="w-8 h-8 text-primary" />
            </div>
            <CardTitle className="text-2xl font-bold tracking-tight">Attendance Portal</CardTitle>
            <CardDescription className="text-muted-foreground text-sm">Generate your QR pass</CardDescription>
        </CardHeader>
        
        <CardContent className="p-8">
            {error && (
               <div className="mb-6 p-4 bg-destructive/10 text-destructive rounded-lg flex items-start gap-3 text-sm border border-destructive/20 font-medium">
                  <AlertCircle className="w-5 h-5 shrink-0" />
                  <span>{error}</span>
               </div>
            )}

            {!qrData ? (
            <form onSubmit={generateQRCode} className="space-y-5">
                <div className="space-y-2">
                   <label className="text-sm font-semibold tracking-wide text-foreground">Employee ID</label>
                   <Input
                       type="text"
                       required
                       value={empId}
                       onChange={(e) => setEmpId(e.target.value)}
                       placeholder="e.g. EMP001"
                       className="h-12 bg-background border-border focus-visible:ring-primary font-mono text-base"
                   />
                </div>
                <div className="space-y-2">
                   <label className="text-sm font-semibold tracking-wide text-foreground">Full Name</label>
                   <Input
                       type="text"
                       required
                       value={fullName}
                       onChange={(e) => setFullName(e.target.value)}
                       placeholder="e.g. John Doe"
                       className="h-12 bg-background border-border focus-visible:ring-primary text-base"
                   />
                </div>
                
                <Button
                   type="submit"
                   disabled={loading}
                   className="w-full h-12 mt-4 font-bold text-base bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/20 transition-all"
                >
                   {loading ? 'Processing...' : 'Generate QR Code'}
                </Button>
            </form>
            ) : (
            <div className="flex flex-col items-center space-y-6 animate-in fade-in zoom-in duration-300">
                <div className="bg-secondary/20 border border-secondary/40 text-secondary px-4 py-3 rounded-lg flex items-center gap-2 w-full justify-center">
                   <CheckCircle2 className="w-5 h-5" />
                   <span className="font-semibold tracking-wide">QR Generated Successfully</span>
                </div>
                
                <div className="p-4 bg-white rounded-2xl relative shadow-xl ring-4 ring-white/10">
                   <QRCodeSVG value={qrData} size={220} level="H" includeMargin={true} />
                </div>

                <div className="text-center w-full bg-muted/40 p-5 rounded-xl border border-border">
                   <p className="text-muted-foreground text-xs font-bold mb-2 uppercase tracking-widest">Code expires in</p>
                   <div className="text-5xl font-mono font-bold text-foreground tracking-tighter drop-shadow-md">
                       {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
                   </div>
                </div>

                <Button
                   variant="outline"
                   onClick={() => {
                       setQrData(null);
                       setTimeLeft(0);
                   }}
                   className="w-full h-12 font-bold hover:bg-muted border-border text-muted-foreground transition-all"
                >
                   Regenerate Code
                </Button>
            </div>
            )}

            {qrData === null && timeLeft === 0 && !error && (empId || fullName) && (
                <div className="mt-6 text-center">
                    <button type="button" onClick={resetForm} className="text-sm font-semibold text-muted-foreground hover:text-primary transition-colors underline underline-offset-4 decoration-muted-foreground/30">Clear Form</button>
                </div>
            )}
        </CardContent>
      </Card>

      {notification && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-in fade-in zoom-in duration-200">
          <Card className="max-w-sm w-full shadow-2xl text-center border-border bg-card">
            <CardContent className="p-10">
                {notification === 'Approved' ? (
                   <div className="w-24 h-24 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6 ring-4 ring-primary/30">
                     <CheckCircle2 className="text-primary w-12 h-12" />
                   </div>
                ) : (
                   <div className="w-24 h-24 bg-destructive/20 rounded-full flex items-center justify-center mx-auto mb-6 ring-4 ring-destructive/30">
                     <XCircle className="text-destructive w-12 h-12" />
                   </div>
                )}
                <h3 className="text-3xl font-extrabold text-foreground mb-3 tracking-tight">
                   {notification === 'Approved' ? 'Approved!' : 'Rejected'}
                </h3>
                <p className="text-muted-foreground font-medium mb-8">Your attendance request has been {notification.toLowerCase()} by the system admin.</p>
                <Button 
                  onClick={() => { setNotification(null); resetForm(); }}
                  variant="secondary"
                  className="w-full h-12 font-bold text-base"
                >
                  Close Window
                </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
