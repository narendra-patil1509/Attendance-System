async function testSignup() {
  try {
    const res = await fetch('http://localhost:5000/api/admin/signup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: 'test_admin_fetch',
        password: 'password123',
        full_name: 'Test Fetch Admin'
      })
    });
    const data = await res.json();
    console.log('Status', res.status);
    console.log('Data', data);
  } catch (err) {
    console.error('Failed:', err);
  }
}
testSignup();
