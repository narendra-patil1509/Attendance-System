const mysql = require('mysql2/promise');
const dotenv = require('dotenv');
const bcrypt = require('bcryptjs');

dotenv.config();

async function initDb() {
  try {
    // Connect without database to create it if it doesn't exist
    const connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASS || '',
      port: process.env.DB_PORT || 3306,
    });

    console.log(`Connected to MySQL Server`);

    // Create database
    await connection.query(`CREATE DATABASE IF NOT EXISTS \`${process.env.DB_NAME}\`;`);
    console.log(`Database \`${process.env.DB_NAME}\` created or already exists.`);

    // Switch to the database
    await connection.query(`USE \`${process.env.DB_NAME}\`;`);

    // Create admins table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS admins (
        admin_id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        full_name VARCHAR(100) NOT NULL
      )
    `);
    console.log('admins table created or already exists.');

    // Create employees table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS employees (
        emp_id VARCHAR(50) PRIMARY KEY,
        full_name VARCHAR(100) NOT NULL,
        mobile_number VARCHAR(20),
        is_active BOOLEAN DEFAULT true
      )
    `);
    console.log('employees table created or already exists.');

    // Create attendance table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS attendance (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id VARCHAR(50) NOT NULL,
        admin_id INT NOT NULL,
        entry_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        status ENUM('Approved', 'Rejected') DEFAULT 'Approved',
        FOREIGN KEY (employee_id) REFERENCES employees(emp_id),
        FOREIGN KEY (admin_id) REFERENCES admins(admin_id)
      )
    `);
    console.log('attendance table created or already exists.');

    // Seed admin if not exists
    const [adminRows] = await connection.query(`SELECT * FROM admins WHERE username = 'admin'`);
    if (adminRows.length === 0) {
      const hashedPassword = await bcrypt.hash('admin123', 10);
      await connection.query(
        `INSERT INTO admins (username, password_hash, full_name) VALUES (?, ?, ?)`,
        ['admin', hashedPassword, 'System Admin']
      );
      console.log('Default admin seeded (admin / admin123).');
    }

    // Seed some mock employees if not exists
    const [empRows] = await connection.query(`SELECT * FROM employees LIMIT 1`);
    if (empRows.length === 0) {
      await connection.query(`
        INSERT INTO employees (emp_id, full_name, mobile_number, is_active)
        VALUES 
        ('EMP001', 'John Doe', '1234567890', true),
        ('EMP002', 'Jane Smith', '0987654321', true),
        ('EMP003', 'Mike Johnson', '1122334455', true)
      `);
      console.log('Mock employees seeded (EMP001, EMP002, EMP003).');
    }

    await connection.end();
    console.log('Database initialization completed successfully.');
    process.exit(0);
  } catch (error) {
    console.error('Error initializing database:', error);
    process.exit(1);
  }
}

initDb();
