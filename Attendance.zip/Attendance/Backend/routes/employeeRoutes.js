const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const db = require('../config/db');
const multer = require('multer');
const exceljs = require('exceljs');
const upload = multer({ storage: multer.memoryStorage() });

// @desc    Validate employee and generate QR token
// @route   POST /api/employee/generate-qr
// @access  Public
router.post('/generate-qr', async (req, res) => {
  const { emp_id, full_name } = req.body;

  if (!emp_id || !full_name) {
    return res.status(400).json({ message: 'Employee ID and Full Name are required' });
  }

  try {
    // 1. Check if employee exists
    const [employees] = await db.query(
      'SELECT * FROM employees WHERE emp_id = ? AND full_name = ? AND is_active = true',
      [emp_id, full_name]
    );

    if (employees.length === 0) {
      return res.status(404).json({ message: 'Employee not found or inactive' });
    }

    const employee = employees[0];

    // 2. Check if attendance already recorded for today
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    
    const todayEnd = new Date();
    todayEnd.setHours(23, 59, 59, 999);

    const [attendance] = await db.query(
      'SELECT * FROM attendance WHERE employee_id = ? AND status = "Approved" AND entry_timestamp >= ? AND entry_timestamp <= ?',
      [emp_id, todayStart, todayEnd]
    );

    if (attendance.length > 0) {
      return res.status(400).json({ message: 'Attendance already recorded for today.' });
    }

    // 3. Generate QR token (expires in 90 seconds)
    const payload = {
      emp_id: employee.emp_id,
      full_name: employee.full_name,
      mobile_number: employee.mobile_number
    };

    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '90s' });

    res.json({ 
      token, 
      message: 'QR Code generated successfully',
      employee: {
        emp_id: employee.emp_id,
        full_name: employee.full_name
      }
    });

  } catch (error) {
    console.error('Error generating QR:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @desc    Upload Employee Database via Excel
// @route   POST /api/employee/upload
// @access  Public (for now)
router.post('/upload', upload.single('file'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: 'No file uploaded' });
  }

  try {
    const workbook = new exceljs.Workbook();
    await workbook.xlsx.load(req.file.buffer);
    const worksheet = workbook.worksheets[0];
    
    let importedCount = 0;
    const errors = [];
    const promises = [];

    worksheet.eachRow((row, rowNumber) => {
      if (rowNumber === 1) return; // Skip header

      const emp_id = row.getCell(1).value?.toString().trim();
      const full_name = row.getCell(2).value?.toString().trim();
      let mobile_number = row.getCell(3).value?.toString().trim() || null;

      if (!emp_id || !full_name) {
        errors.push(`Row ${rowNumber}: Missing emp_id or full_name`);
        return;
      }

      promises.push(
        db.query(`
          INSERT INTO employees (emp_id, full_name, mobile_number, is_active) 
          VALUES (?, ?, ?, true)
          ON DUPLICATE KEY UPDATE 
          full_name = VALUES(full_name), 
          mobile_number = VALUES(mobile_number),
          is_active = true
        `, [emp_id, full_name, mobile_number])
        .then(() => importedCount++)
        .catch((err) => {
          console.error('Error inserting row', rowNumber, err);
          errors.push(`Row ${rowNumber}: Database error`);
        })
      );
    });

    await Promise.all(promises);

    res.status(200).json({ 
      message: `Successfully imported/updated ${importedCount} employees`,
      errors: errors.length > 0 ? errors : undefined
    });
  } catch (error) {
    console.error('Excel processing error:', error);
    res.status(500).json({ message: 'Failed to process Excel file' });
  }
});

module.exports = router;
