const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const excelJS = require('exceljs');
const db = require('../config/db');
const { protect } = require('../middleware/authMiddleware');

// @desc    Verify QR token and log attendance
// @route   POST /api/attendance/verify
// @access  Private (Admin only)
router.post('/verify', protect, async (req, res) => {
  const { token, status } = req.body;

  if (!token || !status) {
    return res.status(400).json({ message: 'Token and status are required' });
  }

  try {
    // Verify 90s token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Check if attendance already recorded today
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);

    const endOfDay = new Date();
    endOfDay.setHours(23, 59, 59, 999);

    const [existing] = await db.query(
      'SELECT id FROM attendance WHERE employee_id = ? AND status = "Approved" AND entry_timestamp BETWEEN ? AND ?',
      [decoded.emp_id, startOfDay, endOfDay]
    );

    if (existing.length > 0 && status === 'Approved') {
      return res.status(400).json({ message: 'Attendance already recorded today' });
    }

    // Insert attendance
    await db.query(
      'INSERT INTO attendance (employee_id, admin_id, status) VALUES (?, ?, ?)',
      [decoded.emp_id, req.admin.id, status]
    );

    // Emit socket event to update dashboard
    if (status === 'Approved') {
       req.io.to('admin-room').emit('new-attendance-entry');
    }

    // Emit real-time notification to the specific employee
    req.io.to(`emp-${decoded.emp_id}`).emit('attendance-update', { status });

    res.json({ message: `Attendance ${status} successfully`, employee: decoded });

  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ message: 'QR Code Expired' });
    }
    console.error(error);
    res.status(500).json({ message: 'Server error or invalid token' });
  }
});

// @desc    Manual check in
// @route   POST /api/attendance/manual
// @access  Private
router.post('/manual', protect, async (req, res) => {
  const { emp_id, status } = req.body;
  if (!emp_id || !status) {
      return res.status(400).json({ message: 'Employee ID and status are required' });
  }

  try {
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);

    const endOfDay = new Date();
    endOfDay.setHours(23, 59, 59, 999);

    const [existing] = await db.query(
      'SELECT id FROM attendance WHERE employee_id = ? AND status = "Approved" AND entry_timestamp BETWEEN ? AND ?',
      [emp_id, startOfDay, endOfDay]
    );

    if (existing.length > 0 && status === 'Approved') {
      return res.status(400).json({ message: 'Attendance already recorded today' });
    }
    
    await db.query(
      'INSERT INTO attendance (employee_id, admin_id, status) VALUES (?, ?, ?)',
      [emp_id, req.admin.id, status]
    );

    if (status === 'Approved') {
      req.io.to('admin-room').emit('new-attendance-entry');
    }

    req.io.to(`emp-${emp_id}`).emit('attendance-update', { status });

    res.json({ message: `Manual attendance ${status} successfully` });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @desc    Get real-time statistics
// @route   GET /api/attendance/stats
// @access  Private
router.get('/stats', protect, async (req, res) => {
  try {
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);

    const endOfDay = new Date();
    endOfDay.setHours(23, 59, 59, 999);

    // Get total active employees
    const [totalEmpResult] = await db.query('SELECT COUNT(*) as total FROM employees WHERE is_active = true');
    const totalExpected = totalEmpResult[0].total;

    // Get entered today
    const [enteredResult] = await db.query(
      'SELECT COUNT(DISTINCT employee_id) as entered FROM attendance WHERE status = "Approved" AND entry_timestamp BETWEEN ? AND ?',
      [startOfDay, endOfDay]
    );
    const entered = enteredResult[0].entered;

    // Admin specific logs (approved by current admin)
    const [adminLogsResult] = await db.query(
      'SELECT COUNT(*) as logs FROM attendance WHERE admin_id = ? AND status = "Approved" AND entry_timestamp BETWEEN ? AND ?',
      [req.admin.id, startOfDay, endOfDay]
    );

    res.json({
      totalExpected,
      entered,
      remaining: totalExpected - entered,
      adminApprovedLog: adminLogsResult[0].logs
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @desc    Get all attendance for today
// @route   GET /api/attendance/today
// @access  Private
router.get('/today', protect, async (req, res) => {
  try {
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);

    const endOfDay = new Date();
    endOfDay.setHours(23, 59, 59, 999);

    const [logs] = await db.query(`
      SELECT a.id, e.full_name as employee_name, e.emp_id, a.entry_timestamp, a.status, ad.full_name as admin_name 
      FROM attendance a
      JOIN employees e ON a.employee_id = e.emp_id
      JOIN admins ad ON a.admin_id = ad.admin_id
      WHERE a.entry_timestamp BETWEEN ? AND ?
      ORDER BY a.entry_timestamp DESC
    `, [startOfDay, endOfDay]);

    res.json(logs);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @desc    Export attendance to Excel
// @route   GET /api/attendance/export
// @access  Private
router.get('/export', protect, async (req, res) => {
  try {
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);

    const endOfDay = new Date();
    endOfDay.setHours(23, 59, 59, 999);

    const [logs] = await db.query(`
      SELECT e.full_name as 'Employee Name', e.emp_id as 'Employee ID', a.entry_timestamp as 'Entry Time', ad.full_name as 'Approving Admin Name', a.status as 'Status'
      FROM attendance a
      JOIN employees e ON a.employee_id = e.emp_id
      JOIN admins ad ON a.admin_id = ad.admin_id
      WHERE a.entry_timestamp BETWEEN ? AND ?
      ORDER BY a.entry_timestamp DESC
    `, [startOfDay, endOfDay]);

    const workbook = new excelJS.Workbook();
    const worksheet = workbook.addWorksheet('Today Attendance');

    worksheet.columns = [
      { header: 'Employee Name', key: 'Employee Name', width: 25 },
      { header: 'Employee ID', key: 'Employee ID', width: 15 },
      { header: 'Entry Time', key: 'Entry Time', width: 25 },
      { header: 'Approving Admin Name', key: 'Approving Admin Name', width: 25 },
      { header: 'Status', key: 'Status', width: 15 }
    ];

    logs.forEach(log => {
      worksheet.addRow(log);
    });

    res.setHeader(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    );
    res.setHeader(
      'Content-Disposition',
      'attachment; filename=' + 'attendance.xlsx'
    );

    await workbook.xlsx.write(res);
    res.status(200).end();
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error during export' });
  }
});

// Search employees for manual entry
router.get('/search', protect, async (req, res) => {
    const q = req.query.q || '';
    try {
        const [employees] = await db.query(
            "SELECT emp_id, full_name, mobile_number FROM employees WHERE emp_id LIKE ? OR full_name LIKE ? LIMIT 10",
            [`%${q}%`, `%${q}%`]
        );
        res.json(employees);
    } catch(err) {
        res.status(500).json({message: "Server error"});
    }
});

module.exports = router;
