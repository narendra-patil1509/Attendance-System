const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const db = require('../config/db');

// @desc    Auth admin & get token
// @route   POST /api/admin/login
// @access  Public
router.post('/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const [admins] = await db.query('SELECT * FROM admins WHERE username = ?', [username]);

    if (admins.length === 0) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const admin = admins[0];

    const isMatch = await bcrypt.compare(password, admin.password_hash);

    if (isMatch) {
      const token = jwt.sign(
        { id: admin.admin_id, username: admin.username, full_name: admin.full_name },
        process.env.JWT_SECRET,
        { expiresIn: '8h' }
      );

      res.json({
        admin_id: admin.admin_id,
        username: admin.username,
        full_name: admin.full_name,
        token
      });
    } else {
      res.status(401).json({ message: 'Invalid credentials' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @desc    Register admin
// @route   POST /api/admin/signup
// @access  Public
router.post('/signup', async (req, res) => {
  const { username, password, full_name } = req.body;

  try {
    const [existing] = await db.query('SELECT * FROM admins WHERE username = ?', [username]);
    if (existing.length > 0) {
      return res.status(400).json({ message: 'Username already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    
    const [result] = await db.query(
      'INSERT INTO admins (username, password_hash, full_name) VALUES (?, ?, ?)',
      [username, hashedPassword, full_name]
    );

    res.status(201).json({ message: 'Admin registered successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
